import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();

  factory NotificationService() => _instance;

  NotificationService._internal();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const String channelId = 'new_orders_channel';
  static const String channelName = 'New Orders';
  static const String channelDescription =
      'Alerts for incoming restaurant orders';

  static const MethodChannel _overlayChannel =
      MethodChannel('com.example.maruthi_eats_admin/overlay');

  Future<bool> checkOverlayPermission() async {
    if (kIsWeb) return true;
    try {
      final bool? granted =
          await _overlayChannel.invokeMethod<bool>('checkOverlayPermission');
      return granted ?? true;
    } catch (e) {
      debugPrint('Error checking overlay permission: $e');
      return true;
    }
  }

  Future<bool> requestOverlayPermission() async {
    if (kIsWeb) return true;
    try {
      final bool? result =
          await _overlayChannel.invokeMethod<bool>('requestOverlayPermission');
      return result ?? true;
    } catch (e) {
      debugPrint('Error requesting overlay permission: $e');
      return true;
    }
  }

  Future<void> bringAppToForeground() async {
    if (kIsWeb) return;
    try {
      await _overlayChannel.invokeMethod('bringToForeground');
    } catch (e) {
      debugPrint('Error bringing app to foreground: $e');
    }
  }

  Future<void> requestPermissions() async {
    if (kIsWeb) return;

    try {
      // 1. Request FCM Notification permissions (iOS / Android)
      NotificationSettings settings = await _fcm.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        criticalAlert: true,
        provisional: false,
      );
      debugPrint('FCM permission status: ${settings.authorizationStatus}');

      // 2. Request Android 13+ POST_NOTIFICATIONS runtime permission
      final androidImplementation = _localNotifications
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();

      if (androidImplementation != null) {
        final granted =
            await androidImplementation.requestNotificationsPermission();
        debugPrint('Android local notification permission granted: $granted');
      }

      // 3. Request "Display over other apps" (SYSTEM_ALERT_WINDOW) for background full-screen overlay
      final overlayGranted = await checkOverlayPermission();
      if (!overlayGranted) {
        await requestOverlayPermission();
      }

      // 4. Request Android 14+ Full Screen Intent permission if needed
      try {
        await _overlayChannel.invokeMethod('requestFullScreenIntentPermission');
      } catch (e) {
        debugPrint('Full screen intent permission request error: $e');
      }
    } catch (e) {
      debugPrint('Error requesting notification permissions: $e');
    }
  }

  Future<void> initialize() async {
    if (kIsWeb) {
      try {
        await _fcm.requestPermission(
          alert: true,
          badge: true,
          sound: true,
        );
        FirebaseMessaging.onMessage.listen((RemoteMessage message) {
          // Web FCM handling if needed
        });
      } catch (e) {
        debugPrint('Web FCM notification setup skipped/failed: $e');
      }
      return;
    }

    // 1. Request permissions
    await requestPermissions();

    // 2. Configure Local Notifications (Mobile)
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/launcher_icon');
    const InitializationSettings initSettings =
        InitializationSettings(android: androidSettings);

    await _localNotifications.initialize(
      settings: initSettings,
      onDidReceiveNotificationResponse: (details) {
        debugPrint('Notification tapped with payload: ${details.payload}');
      },
    );

    // 3. Create Android Channel with custom sound and max importance
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      channelId,
      channelName,
      description: channelDescription,
      importance: Importance.max,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('notification'),
      enableVibration: true,
      showBadge: true,
    );

    final androidImplementation = _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidImplementation != null) {
      await androidImplementation.createNotificationChannel(channel);
    }

    // 4. Handle Foreground FCM Messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      _showOrderNotification(message);
    });

    // 5. Handle Notification Click (when app is in background or terminated)
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('FCM message opened app: ${message.data}');
    });

    // 6. Subscribe to admin_orders FCM topic
    try {
      await _fcm.subscribeToTopic('admin_orders');
    } catch (e) {
      debugPrint('Error subscribing to admin_orders topic: $e');
    }

    // 7. Check if app was launched from a terminated state via FCM
    final initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      debugPrint('FCM initial message: ${initialMessage.data}');
    }
  }

  static Future<void> showBackgroundNotification(RemoteMessage message) async {
    if (kIsWeb) return;
    final service = NotificationService();
    await service._showOrderNotification(message);
  }

  Future<void> _showOrderNotification(RemoteMessage message) async {
    if (kIsWeb) return;
    // We only show high-priority popup for 'placed' orders
    if (message.data['status'] != null && message.data['status'] != 'placed') {
      return;
    }

    // Attempt to bring the app activity to the foreground immediately
    await bringAppToForeground();

    final AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDescription,
      importance: Importance.max,
      priority: Priority.high,
      fullScreenIntent: true,
      sound: const RawResourceAndroidNotificationSound('notification'),
      audioAttributesUsage: AudioAttributesUsage.alarm,
      category: AndroidNotificationCategory.call,
      visibility: NotificationVisibility.public,
      styleInformation: const BigTextStyleInformation(''),
    );

    final NotificationDetails details =
        NotificationDetails(android: androidDetails);

    await _localNotifications.show(
      id: message.hashCode,
      title: message.notification?.title ?? 'New Order Received!',
      body: message.notification?.body ??
          'A new order has been placed. Tap to view.',
      notificationDetails: details,
      payload: jsonEncode(message.data),
    );
  }

  Future<String?> getToken() => _fcm.getToken();
}
